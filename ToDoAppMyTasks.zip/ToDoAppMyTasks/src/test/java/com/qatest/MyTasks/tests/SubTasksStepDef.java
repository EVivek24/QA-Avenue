
package com.qatest.MyTasks.tests;

import org.junit.Assert;
import org.openqa.selenium.By;

import com.qatest.MyTasks.Base.BaseClass;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SubTasksStepDef extends BaseClass {
	
	int beforeCount,afterCount;
	
	
	
	
@Given("^user is on MyTaskPage$")
public void user_is_on_MyTaskPage()  {
	BaseClass.initialization();
	loginpage = homepage.navigateToMyTasks();
	taskpage = loginpage.login(prop.getProperty("EmailID"), prop.getProperty("password"));
	
}

@Then("^user should see the Manage SubTasks button$")
public void user_should_see_the_Manage_SubTasks_button() {
    boolean flag=taskpage.validateSubTaskButton();
    Assert.assertTrue(flag);
}

@Then("^user should see the number of subtasks$")
public void user_should_see_the_number_of_subtasks()  {
	
	String strCount=taskpage.validateSubTaskCount();
	 Assert.assertTrue(strCount, true);
    
}

@When("^user clicks Manage Subtasks$")
public void user_clicks_Manage_Subtasks() {
	subtaskpage = taskpage.selectSubTask();
    
}

@Then("^modal dialog should open$")
public void modal_dialog_should_open() {
	boolean flag =subtaskpage.validateSubTaskModal();
	Assert.assertTrue(flag);
   
}

@Given("^user is on SubTask Page$")
public void user_is_on_SubTask_Page() {
	BaseClass.initialization();
	loginpage = homepage.navigateToMyTasks();
	taskpage = loginpage.login(prop.getProperty("EmailID"), prop.getProperty("password"));
	subtaskpage = taskpage.selectSubTask();
}

@Then("^user should see task ID and description as read only$")
public void user_should_see_task_ID_and_description_as_read_only() {
   	
    String title = driver.findElement(By.xpath("//h3[contains(text(),'Editing')]")).getText();
   String taskdesc = driver.findElement(By.xpath("//textarea[@ng-model = 'task.body']")).getText();
      
   String expected = (title + taskdesc);
  
    Assert.assertNotEquals(expected, title);
    
    
}

@Then("^description equals (\\d+) characters$")
public void description_equals_characters(int i) {
	
	String actualLength = subtaskpage.getSubTaskLength();
	String expectedLength = "250";
	Assert.assertEquals(expectedLength, actualLength);
    
}
@Then("^date format is MM/dd/yyyy$")
public void date_format_is_MM_dd_yyyy() {
	String actualFormat = subtaskpage.getDateFormat();
	String expectedFormat = "MM/dd/yyyy";
	Assert.assertEquals(actualFormat, expectedFormat);
    
}

@When("^user leaves description and due date empty$")
public void user_leaves_description_and_due_date_empty()  {
    subtaskpage.clearSubTaskDesc();
	subtaskpage.clearDueDate();
}

@When("^clicks add button$")
public void clicks_add_button()  {
	beforeCount = subtaskpage.getSubTaskCount();
	subtaskpage.addSubTask();
	afterCount = subtaskpage.getSubTaskCount();
}

@Then("^new Subtask not added$")
public void new_Subtask_not_added() {
	Assert.assertTrue(afterCount == beforeCount);
}

@Then("^new Subtask is added$")
public void new_Subtask_is_added() {
    Assert.assertTrue(afterCount>beforeCount);
}

	
}
