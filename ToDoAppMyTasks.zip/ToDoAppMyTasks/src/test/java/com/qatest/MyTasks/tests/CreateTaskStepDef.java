package com.qatest.MyTasks.tests;

import org.junit.Rule;
import org.junit.rules.ErrorCollector;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.qatest.MyTasks.Base.BaseClass;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

import static org.assertj.core.api.Assertions.assertThat;

public class CreateTaskStepDef extends BaseClass {
	
	String message,actual, taskDesc;
	int beforeCount, afterCount;
	
	@Rule
	public ErrorCollector collector = new ErrorCollector();
	
	@Given("^user is on home page$")
	public void user_is_on_home_page() throws Throwable {
		BaseClass.initialization();
	}

	@Given("^sees MyTasks Link$")
	public void sees_MyTasks_Link() throws Throwable {
		boolean flag =homepage.validateMyTasksLink();
		Assert.assertTrue(flag);
	}
	
	@Then("^user clicks MyTasks link$")
	public void user_clicks_MyTasks_link() throws Throwable {
		loginpage = homepage.navigateToMyTasks();
		
	}

	@Then("^navigates to MyTasks page$")
	public void navigates_to_MyTasks_page() throws Throwable {
		
		loginpage = homepage.navigateToMyTasks();
	}
	
	@After
    public void afterTest() {
        
		//taskpage.removeTask();
		driver.quit();

    }
	

	@Given("^user is on MyTasks page$")
	public void user_is_on_MyTasks_page() throws Throwable {
		BaseClass.initialization();
		loginpage = homepage.navigateToMyTasks();
		taskpage = loginpage.login(prop.getProperty("EmailID"), prop.getProperty("password"));
		
		
	}

	@When("^user checks Message$")
	public void user_checks_Message() throws Throwable {
		message = taskpage.validateMessage();
	    actual = "Hey ([^\"]*), this is your todo list for today:";
		
	}

	@Then("^proper message should be displayed$")
	public void proper_message_should_be_displayed()  {
		Assert.assertEquals(actual, message);

//		try {
//    		Assert.assertEquals(actual, message);
//    	
//    	} 
//    catch (Throwable e)    {
//    	System.out.println("Message mismatch");
//    	System.out.println(e);
//    	collector.addError(e);
//    	
//    	} 
	}

	@When("^user clicks add button$")
	public void user_clicks_add_button() throws Throwable {
		beforeCount = taskpage.getTaskCount();
		taskpage.addNewTask();
		afterCount = taskpage.getTaskCount();
		
	    
	}

	@When("^user hits enter key$")
	public void user_hits_enter_key() throws Throwable {
		beforeCount = taskpage.getTaskCount();
		taskpage.enterNewTask();
		afterCount = taskpage.getTaskCount();
	}

	@When("^user enters at least (\\d+) characters$")
	public void user_enters_at_least_characters(int arg1) throws Throwable {
		taskDesc = prop.getProperty("mintask");
    	taskpage.inputTaskDescription(taskDesc);
    	beforeCount = taskpage.getTaskCount();
		taskpage.enterNewTask();
		afterCount = taskpage.getTaskCount();
	}

	@When("^user types more than (\\d+) characters$")
	public void user_types_more_than_characters(int arg1) throws Throwable {
		taskDesc = prop.getProperty("maxtask");
    	taskpage.inputTaskDescription(taskDesc);
    	beforeCount = taskpage.getTaskCount();
		taskpage.enterNewTask();
		afterCount = taskpage.getTaskCount();
	}

	@Then("^task not added$")
	public void task_not_added() /*throws Throwable */{
	
		Assert.assertTrue(afterCount == beforeCount);
	
 System.out.println(afterCount);
 System.out.println(beforeCount);
		}
	

	@Given("^user has entered the task$")
	public void user_has_entered_the_task() throws Throwable {
		BaseClass.initialization();
		loginpage = homepage.navigateToMyTasks();
		taskpage = loginpage.login(prop.getProperty("EmailID"), prop.getProperty("password"));
		taskDesc = prop.getProperty("task");
    	taskpage.inputTaskDescription(taskDesc);
    	beforeCount = taskpage.getTaskCount();
		taskpage.enterNewTask();
		afterCount = taskpage.getTaskCount();
	}

	@Then("^new task should be added to existing list$")
	public void new_task_should_be_added_to_existing_list() throws Throwable {
		
			try {
				if (afterCount>beforeCount){
	   				assertThat(true);
				}
	    	} 
	    catch (Throwable e)    {
	    	System.out.println("task not added to existing list");
	    	System.out.println(e);
	    	collector.addError(e);
	    	
	    	} 
			
		}
	
	@Then("^task is added$")
	public void task_is_added() throws Throwable {
		try {
			if (afterCount>beforeCount){
			assertThat(true);
			}
    	} 
    catch (Throwable e)    {
    	System.out.println("task not added to existing list");
    	System.out.println(e);
    	collector.addError(e);
    	
    	} 
	}

}
