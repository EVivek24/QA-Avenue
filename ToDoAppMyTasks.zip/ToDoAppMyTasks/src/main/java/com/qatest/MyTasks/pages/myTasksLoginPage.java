package com.qatest.MyTasks.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qatest.MyTasks.Base.BaseClass;

import org.junit.runner.JUnitCore;		
import org.junit.runner.Result;		
import org.junit.runner.notification.Failure;

public class myTasksLoginPage extends BaseClass {
	
	WebDriver driver;
	public myTasksLoginPage(WebDriver driver){
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	
	@FindBy(xpath = "//input[@id='user_email']")
	WebElement EmailID;
	
	@FindBy(xpath = "//input[@id='user_password']" )
	WebElement password;
	
	@FindBy(xpath = "//input[@id ='user_remember_me']" )
	WebElement rememberme;
	
	@FindBy(xpath ="//input[@name='commit']")
	WebElement signin;
	
	@FindBy(linkText = "Sign Up")
	WebElement signup;
	
	public String validateMyTasksLoginPageTitle(){
		return driver.getTitle();
	}
	
	public myTasksPage login(String un, String pwd){
		EmailID.sendKeys(un);
		password.sendKeys(pwd);
		signin.click();
		Object a = new myTasksPage(driver);
//		Result result = JUnitCore.runClasses(MyTasksTest.class);					
//		for (Failure failure : result.getFailures()) {	
//			   System.out.println(failure.toString());					
//		  }
		return (myTasksPage) a;	


	}
	
	

}
