package com.qatest.MyTasks.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qatest.MyTasks.Base.BaseClass;

public class subTasksPage extends BaseClass {
	
	WebDriver driver;
	public subTasksPage(WebDriver driver){
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	// xpath for header
	
	@FindBy(xpath = "//div[@class='modal-content']")
	WebElement subTaskContent;
	
	@FindBy(xpath = "//h3[contains(text(),'Editing')]")
	WebElement subTaskTitle;
	
	@FindBy(xpath = "//textarea[@id = 'edit_task']")
	WebElement taskName;
	
	@FindBy(xpath = "//input[@name ='new_sub_task']")
	WebElement subTaskDesc;
	
	@FindBy(css = "#dueDate")
	WebElement dueDate;
	
	@FindBy(xpath = "//button[@id='add-subtask']")
	WebElement addsubTask;
	
	@FindBy(xpath ="//div[@ng-show='task.sub_tasks.length']/table/tbody")
	WebElement stable;
	
	@FindBy(css = "tr.ng-scope")
	WebElement scount;
	
	@FindBy(xpath = "//button[@ng-click='close()']")
	WebElement close;
		
	public subTasksPage(){
		PageFactory.initElements(driver, this);
	}
	
	public boolean validateSubTaskModal(){
		driver.switchTo().defaultContent();
		boolean flag = subTaskContent.isDisplayed();
		return flag;
	}
	
	public String validatesubTaskTitle(){
		
			String st =	subTaskTitle.getText();
		System.out.println(st);
		return st;
	}
	
	public String getTaskName(){
		String ts = taskName.getText();
		System.out.println(ts);
		return ts;
	}
	
	public void inputSubTaskDesc(){
		subTaskDesc.sendKeys();
	}
	
	public String getSubTaskLength(){
		String length = subTaskDesc.getAttribute("maxlength");
		return length;
	}
	
	public String getDateFormat(){
		String format = dueDate.getAttribute("placeholder");
		return format;
	}
	
	public void clearSubTaskDesc(){
		subTaskDesc.clear();
	}
	
	public void clearDueDate(){
		dueDate.clear();
	}
	
	public void inputDueDate(){
		dueDate.sendKeys();
	}
	
	public void addSubTask(){
		addsubTask.sendKeys(Keys.ENTER);;
	}
	
	public int getSubTaskCount(){
		int taskCount = stable.findElements(By.cssSelector("tr.ng-scope")).size();
	    
		
		return taskCount;
	}

}
