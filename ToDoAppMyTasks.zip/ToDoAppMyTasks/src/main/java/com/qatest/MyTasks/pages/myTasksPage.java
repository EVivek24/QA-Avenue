package com.qatest.MyTasks.pages;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qatest.MyTasks.Base.BaseClass;

public class myTasksPage extends BaseClass {
	
	WebDriver driver;
	

	
	public myTasksPage(WebDriver driver){
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	
	@FindBy(xpath = "//h1[contains(text(),'ToDo List')]")
	WebElement message;
	
	@FindBy(id = "new_task")
	WebElement desc;
	
	@FindBy(xpath = "//span[@ng-click='addTask()']")
	WebElement addTask;
	
	@FindBy(linkText = "Sign out")
	WebElement signout;
	
	@FindBy(xpath = "//button[@ng-click='editModal(task)']")
	WebElement manageSubTask;
	
	@FindBy(xpath = "//button[@ng-click='removeTask(task)']")
	WebElement remove;
	
	@FindBy(css= "table.table")
	WebElement table;
	
	@FindBy(css = "tr.ng-scope")
	WebElement taskCount;
		
	//Validate page title
	public String validateMyTasksPageTitle(){
		return driver.getTitle();
	}
	
	public String validateMessage(){
		return message.getText();
	}
	
	public void inputTaskDescription(String input){
		desc.sendKeys(input);
		
	}
	
	public void addNewTask(){
		
		addTask.click();
	}
	
	public void enterNewTask(){
		desc.sendKeys(Keys.ENTER);
	}
	
	public subTasksPage selectSubTask(){
		 manageSubTask.click();
		 return new subTasksPage(driver);
		
	}
	
	public int getTaskCount(){
		
		int taskCount = table.findElements(By.cssSelector("tr.ng-scope")).size();
		return taskCount;
	}
	
	public boolean validateSubTaskButton(){
		boolean flag = manageSubTask.isDisplayed();
		return flag;
	}
	
	public String validateSubTaskCount(){
		String s =manageSubTask.getText();
		String n = s.substring(s.indexOf('(')+1, s.indexOf(')') );
		return n;
	}
	public void removeTask(){
		remove.click();
	}
	

}
