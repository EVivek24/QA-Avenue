package com.qatest.MyTasks.pages;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qatest.MyTasks.Base.BaseClass;

public class homePage extends BaseClass{
	WebDriver driver=null;
	public homePage(WebDriver driver){
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}
	
	//WebDriver driver;
	
	@FindBy(linkText = "Home")
	WebElement home;
	
	@FindBy(linkText = "My Tasks")
	WebElement myTasks;
	
	@FindBy(linkText = "Sign In")
	WebElement signin;
	
	@FindBy(linkText = "Register")
	WebElement register;
		
	//Validate home page title
	public String validateHomePageTitle(){
		return driver.getTitle();
	}
	
	//Validate MyTasks is present

	public boolean validateMyTasksLink(){
		return myTasks.isEnabled();
	}
	
	public myTasksLoginPage navigateToMyTasks(){
		myTasks.click();
		return new myTasksLoginPage(driver);
	}
	
		
}
