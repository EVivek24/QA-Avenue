package com.qatest.MyTasks.Base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.qatest.MyTasks.pages.homePage;
import com.qatest.MyTasks.pages.myTasksLoginPage;
import com.qatest.MyTasks.pages.myTasksPage;
import com.qatest.MyTasks.pages.subTasksPage;


public class BaseClass {
	
	public static WebDriver driver= null;
	public static Properties prop;
	public static homePage homepage;
	public static myTasksLoginPage loginpage;
	public static myTasksPage taskpage;
	public static subTasksPage subtaskpage;
	
	
	public BaseClass(){
		try {
			prop = new Properties();
			
			FileInputStream input = new FileInputStream(System.getProperty("user.dir")+ "/src/main/java/com/qatest/MyTasks/config/config.properties");
			prop.load(input);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void initialization(){
		String browserName = prop.getProperty("browser");
		
		if(browserName.equals("chrome")){
			System.setProperty("webdriver.chrome.driver", "D:\\Selenium\\Java\\chromedriver.exe");	
			driver = new ChromeDriver(); 
		}
		else if(browserName.equals("FireFox")){
			System.setProperty("webdriver.gecko.driver", "D:\\Selenium\\Java\\geckodriver.exe");	
			driver = new FirefoxDriver(); 
		}
		
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		driver.get(prop.getProperty("url"));
		homepage = new homePage(driver);
		
	}

}
