$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("SubTask.feature");
formatter.feature({
  "line": 1,
  "name": "Create SubTask",
  "description": "\r\nIn order to breakdown my tasks into smaller pieces\r\nAs a ToDo App user\r\nI need to create subtasks",
  "id": "create-subtask",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 7,
  "name": "Manage subtask button visible",
  "description": "",
  "id": "create-subtask;manage-subtask-button-visible",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 8,
  "name": "user is on MyTaskPage",
  "keyword": "Given "
});
formatter.step({
  "line": 9,
  "name": "user should see the Manage SubTasks button",
  "keyword": "Then "
});
formatter.match({
  "location": "SubTasksStepDef.user_is_on_MyTaskPage()"
});
formatter.result({
  "duration": 16839433750,
  "status": "passed"
});
formatter.match({
  "location": "SubTasksStepDef.user_should_see_the_Manage_SubTasks_button()"
});
formatter.result({
  "duration": 450753541,
  "status": "passed"
});
formatter.after({
  "duration": 714137453,
  "status": "passed"
});
formatter.scenario({
  "line": 11,
  "name": "Number of subtasks",
  "description": "",
  "id": "create-subtask;number-of-subtasks",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 12,
  "name": "user is on MyTaskPage",
  "keyword": "Given "
});
formatter.step({
  "line": 13,
  "name": "user should see the number of subtasks",
  "keyword": "Then "
});
formatter.match({
  "location": "SubTasksStepDef.user_is_on_MyTaskPage()"
});
formatter.result({
  "duration": 15711589698,
  "status": "passed"
});
formatter.match({
  "location": "SubTasksStepDef.user_should_see_the_number_of_subtasks()"
});
formatter.result({
  "duration": 364532041,
  "status": "passed"
});
formatter.after({
  "duration": 732833370,
  "status": "passed"
});
formatter.scenario({
  "line": 15,
  "name": "Validate Modal Dialog",
  "description": "",
  "id": "create-subtask;validate-modal-dialog",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 16,
  "name": "user is on MyTaskPage",
  "keyword": "Given "
});
formatter.step({
  "line": 17,
  "name": "user clicks Manage Subtasks",
  "keyword": "When "
});
formatter.step({
  "line": 18,
  "name": "modal dialog should open",
  "keyword": "Then "
});
formatter.match({
  "location": "SubTasksStepDef.user_is_on_MyTaskPage()"
});
formatter.result({
  "duration": 17193925684,
  "status": "passed"
});
formatter.match({
  "location": "SubTasksStepDef.user_clicks_Manage_Subtasks()"
});
formatter.result({
  "duration": 516431816,
  "status": "passed"
});
formatter.match({
  "location": "SubTasksStepDef.modal_dialog_should_open()"
});
formatter.result({
  "duration": 47090210,
  "status": "passed"
});
formatter.after({
  "duration": 731496875,
  "status": "passed"
});
formatter.scenario({
  "line": 20,
  "name": "Task ID and description are read only",
  "description": "",
  "id": "create-subtask;task-id-and-description-are-read-only",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 21,
  "name": "user is on SubTask Page",
  "keyword": "Given "
});
formatter.step({
  "line": 22,
  "name": "user should see task ID and description as read only",
  "keyword": "Then "
});
formatter.match({
  "location": "SubTasksStepDef.user_is_on_SubTask_Page()"
});
formatter.result({
  "duration": 16218206592,
  "status": "passed"
});
formatter.match({
  "location": "SubTasksStepDef.user_should_see_task_ID_and_description_as_read_only()"
});
formatter.result({
  "duration": 95059038,
  "error_message": "java.lang.AssertionError: Values should be different. Actual: \r\n\tat org.junit.Assert.fail(Assert.java:88)\r\n\tat org.junit.Assert.failEquals(Assert.java:185)\r\n\tat org.junit.Assert.assertNotEquals(Assert.java:161)\r\n\tat org.junit.Assert.assertNotEquals(Assert.java:175)\r\n\tat com.qatest.MyTasks.tests.SubTasksStepDef.user_should_see_task_ID_and_description_as_read_only(SubTasksStepDef.java:72)\r\n\tat ✽.Then user should see task ID and description as read only(SubTask.feature:22)\r\n",
  "status": "failed"
});
formatter.after({
  "duration": 727031883,
  "status": "passed"
});
formatter.scenario({
  "line": 24,
  "name": "validating description length",
  "description": "",
  "id": "create-subtask;validating-description-length",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 25,
  "name": "user is on SubTask Page",
  "keyword": "Given "
});
formatter.step({
  "line": 26,
  "name": "description equals 250 characters",
  "keyword": "Then "
});
formatter.match({
  "location": "SubTasksStepDef.user_is_on_SubTask_Page()"
});
formatter.result({
  "duration": 17366679598,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "250",
      "offset": 19
    }
  ],
  "location": "SubTasksStepDef.description_equals_characters(int)"
});
formatter.result({
  "duration": 32777113,
  "error_message": "org.junit.ComparisonFailure: expected:\u003c25[0]\u003e but was:\u003c25[4]\u003e\r\n\tat org.junit.Assert.assertEquals(Assert.java:115)\r\n\tat org.junit.Assert.assertEquals(Assert.java:144)\r\n\tat com.qatest.MyTasks.tests.SubTasksStepDef.description_equals_characters(SubTasksStepDef.java:82)\r\n\tat ✽.Then description equals 250 characters(SubTask.feature:26)\r\n",
  "status": "failed"
});
formatter.after({
  "duration": 713677206,
  "status": "passed"
});
formatter.scenario({
  "line": 28,
  "name": "vaildating date format",
  "description": "",
  "id": "create-subtask;vaildating-date-format",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 29,
  "name": "user is on SubTask Page",
  "keyword": "Given "
});
formatter.step({
  "line": 30,
  "name": "date format is MM/dd/yyyy",
  "keyword": "Then "
});
formatter.match({
  "location": "SubTasksStepDef.user_is_on_SubTask_Page()"
});
formatter.result({
  "duration": 17358701715,
  "status": "passed"
});
formatter.match({
  "location": "SubTasksStepDef.date_format_is_MM_dd_yyyy()"
});
formatter.result({
  "duration": 29536418,
  "status": "passed"
});
formatter.after({
  "duration": 730546750,
  "status": "passed"
});
formatter.scenario({
  "line": 32,
  "name": "Description and due date are mandatory",
  "description": "",
  "id": "create-subtask;description-and-due-date-are-mandatory",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 33,
  "name": "user is on SubTask Page",
  "keyword": "Given "
});
formatter.step({
  "line": 34,
  "name": "user leaves description and due date empty",
  "keyword": "When "
});
formatter.step({
  "line": 35,
  "name": "clicks add button",
  "keyword": "And "
});
formatter.step({
  "line": 36,
  "name": "new Subtask not added",
  "keyword": "Then "
});
formatter.match({
  "location": "SubTasksStepDef.user_is_on_SubTask_Page()"
});
formatter.result({
  "duration": 16327331814,
  "status": "passed"
});
formatter.match({
  "location": "SubTasksStepDef.user_leaves_description_and_due_date_empty()"
});
formatter.result({
  "duration": 100206301,
  "status": "passed"
});
formatter.match({
  "location": "SubTasksStepDef.clicks_add_button()"
});
formatter.result({
  "duration": 20178622956,
  "status": "passed"
});
formatter.match({
  "location": "SubTasksStepDef.new_Subtask_not_added()"
});
formatter.result({
  "duration": 182124,
  "error_message": "java.lang.AssertionError\r\n\tat org.junit.Assert.fail(Assert.java:86)\r\n\tat org.junit.Assert.assertTrue(Assert.java:41)\r\n\tat org.junit.Assert.assertTrue(Assert.java:52)\r\n\tat com.qatest.MyTasks.tests.SubTasksStepDef.new_Subtask_not_added(SubTasksStepDef.java:108)\r\n\tat ✽.Then new Subtask not added(SubTask.feature:36)\r\n",
  "status": "failed"
});
formatter.after({
  "duration": 708165695,
  "status": "passed"
});
formatter.scenario({
  "line": 38,
  "name": "new subtask added to existing list",
  "description": "",
  "id": "create-subtask;new-subtask-added-to-existing-list",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 39,
  "name": "user is on SubTask Page",
  "keyword": "Given "
});
formatter.step({
  "line": 40,
  "name": "clicks add button",
  "keyword": "When "
});
formatter.step({
  "line": 41,
  "name": "new Subtask is added",
  "keyword": "Then "
});
formatter.match({
  "location": "SubTasksStepDef.user_is_on_SubTask_Page()"
});
formatter.result({
  "duration": 18696847168,
  "status": "passed"
});
formatter.match({
  "location": "SubTasksStepDef.clicks_add_button()"
});
formatter.result({
  "duration": 20189824545,
  "status": "passed"
});
formatter.match({
  "location": "SubTasksStepDef.new_Subtask_is_added()"
});
formatter.result({
  "duration": 43852,
  "status": "passed"
});
formatter.after({
  "duration": 726394253,
  "status": "passed"
});
formatter.uri("Task1.feature");
formatter.feature({
  "line": 1,
  "name": "Create Task",
  "description": "\r\nIn order to manage my tasks\r\nAs a ToDo App user\r\nI need to create a task",
  "id": "create-task",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 7,
  "name": "navigate to MyTasks page",
  "description": "",
  "id": "create-task;navigate-to-mytasks-page",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 8,
  "name": "user is on home page",
  "keyword": "Given "
});
formatter.step({
  "line": 9,
  "name": "sees MyTasks Link",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "user clicks MyTasks link",
  "keyword": "When "
});
formatter.step({
  "line": 11,
  "name": "navigates to MyTasks page",
  "keyword": "Then "
});
formatter.match({
  "location": "CreateTaskStepDef.user_is_on_home_page()"
});
formatter.result({
  "duration": 9404029949,
  "status": "passed"
});
formatter.match({
  "location": "CreateTaskStepDef.sees_MyTasks_Link()"
});
formatter.result({
  "duration": 54891896,
  "status": "passed"
});
formatter.match({
  "location": "CreateTaskStepDef.user_clicks_MyTasks_link()"
});
formatter.result({
  "duration": 3187989087,
  "status": "passed"
});
formatter.match({
  "location": "CreateTaskStepDef.navigates_to_MyTasks_page()"
});
formatter.result({
  "duration": 2345168075,
  "status": "passed"
});
formatter.after({
  "duration": 709214585,
  "status": "passed"
});
formatter.scenario({
  "line": 13,
  "name": "Validating displayed message",
  "description": "",
  "id": "create-task;validating-displayed-message",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 14,
  "name": "user is on MyTasks page",
  "keyword": "Given "
});
formatter.step({
  "line": 15,
  "name": "user checks Message",
  "keyword": "When "
});
formatter.step({
  "line": 16,
  "name": "proper message should be displayed",
  "keyword": "Then "
});
formatter.match({
  "location": "CreateTaskStepDef.user_is_on_MyTasks_page()"
});
formatter.result({
  "duration": 16088431872,
  "status": "passed"
});
formatter.match({
  "location": "CreateTaskStepDef.user_checks_Message()"
});
formatter.result({
  "duration": 44917764,
  "status": "passed"
});
formatter.match({
  "location": "CreateTaskStepDef.proper_message_should_be_displayed()"
});
formatter.result({
  "duration": 301432,
  "error_message": "junit.framework.ComparisonFailure: expected:\u003c[Hey ([^\"]*), this is your todo list for today:]\u003e but was:\u003c[Vivek Elankumaran\u0027s ToDo List]\u003e\r\n\tat junit.framework.Assert.assertEquals(Assert.java:100)\r\n\tat junit.framework.Assert.assertEquals(Assert.java:107)\r\n\tat com.qatest.MyTasks.tests.CreateTaskStepDef.proper_message_should_be_displayed(CreateTaskStepDef.java:77)\r\n\tat ✽.Then proper message should be displayed(Task1.feature:16)\r\n",
  "status": "failed"
});
formatter.after({
  "duration": 706481941,
  "status": "passed"
});
formatter.scenario({
  "line": 18,
  "name": "Adding a new task",
  "description": "",
  "id": "create-task;adding-a-new-task",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 19,
  "name": "user is on MyTasks page",
  "keyword": "Given "
});
formatter.step({
  "line": 20,
  "name": "user clicks add button",
  "keyword": "When "
});
formatter.step({
  "line": 21,
  "name": "user hits enter key",
  "keyword": "And "
});
formatter.step({
  "line": 22,
  "name": "task is added",
  "keyword": "Then "
});
formatter.match({
  "location": "CreateTaskStepDef.user_is_on_MyTasks_page()"
});
formatter.result({
  "duration": 15235157914,
  "status": "passed"
});
formatter.match({
  "location": "CreateTaskStepDef.user_clicks_add_button()"
});
formatter.result({
  "duration": 658164273,
  "status": "passed"
});
formatter.match({
  "location": "CreateTaskStepDef.user_hits_enter_key()"
});
formatter.result({
  "duration": 145648313,
  "status": "passed"
});
formatter.match({
  "location": "CreateTaskStepDef.task_is_added()"
});
formatter.result({
  "duration": 26469,
  "status": "passed"
});
formatter.after({
  "duration": 715994640,
  "status": "passed"
});
formatter.scenario({
  "line": 24,
  "name": "Validating minimum characters",
  "description": "",
  "id": "create-task;validating-minimum-characters",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 25,
  "name": "user is on MyTasks page",
  "keyword": "Given "
});
formatter.step({
  "line": 26,
  "name": "user enters at least 3 characters",
  "keyword": "When "
});
formatter.step({
  "line": 28,
  "name": "task is added",
  "keyword": "Then "
});
formatter.match({
  "location": "CreateTaskStepDef.user_is_on_MyTasks_page()"
});
formatter.result({
  "duration": 16761067268,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "3",
      "offset": 21
    }
  ],
  "location": "CreateTaskStepDef.user_enters_at_least_characters(int)"
});
formatter.result({
  "duration": 436734369,
  "status": "passed"
});
formatter.match({
  "location": "CreateTaskStepDef.task_is_added()"
});
formatter.result({
  "duration": 32730495,
  "status": "passed"
});
formatter.after({
  "duration": 720552471,
  "status": "passed"
});
formatter.scenario({
  "line": 30,
  "name": "Validating maximum characters",
  "description": "",
  "id": "create-task;validating-maximum-characters",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 31,
  "name": "user is on MyTasks page",
  "keyword": "Given "
});
formatter.step({
  "line": 32,
  "name": "user types more than 250 characters",
  "keyword": "When "
});
formatter.step({
  "line": 33,
  "name": "task not added",
  "keyword": "Then "
});
formatter.match({
  "location": "CreateTaskStepDef.user_is_on_MyTasks_page()"
});
formatter.result({
  "duration": 15983090949,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "250",
      "offset": 21
    }
  ],
  "location": "CreateTaskStepDef.user_types_more_than_characters(int)"
});
formatter.result({
  "duration": 1091358887,
  "status": "passed"
});
formatter.match({
  "location": "CreateTaskStepDef.task_not_added()"
});
formatter.result({
  "duration": 196741,
  "error_message": "junit.framework.AssertionFailedError\r\n\tat junit.framework.Assert.fail(Assert.java:55)\r\n\tat junit.framework.Assert.assertTrue(Assert.java:22)\r\n\tat junit.framework.Assert.assertTrue(Assert.java:31)\r\n\tat com.qatest.MyTasks.tests.CreateTaskStepDef.task_not_added(CreateTaskStepDef.java:128)\r\n\tat ✽.Then task not added(Task1.feature:33)\r\n",
  "status": "failed"
});
formatter.after({
  "duration": 781691482,
  "status": "passed"
});
formatter.scenario({
  "line": 35,
  "name": "Appending new task",
  "description": "",
  "id": "create-task;appending-new-task",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 36,
  "name": "user has entered the task",
  "keyword": "Given "
});
formatter.step({
  "line": 37,
  "name": "new task should be added to existing list",
  "keyword": "Then "
});
formatter.match({
  "location": "CreateTaskStepDef.user_has_entered_the_task()"
});
formatter.result({
  "duration": 16317931708,
  "status": "passed"
});
formatter.match({
  "location": "CreateTaskStepDef.new_task_should_be_added_to_existing_list()"
});
formatter.result({
  "duration": 33976,
  "status": "passed"
});
formatter.after({
  "duration": 718617456,
  "status": "passed"
});
});